
# -*- coding: utf-8 -*-
"""
Accuracy:  Regression 
=====================================

Model evaluation
"""

#%%
# Imports
from piml import Experiment
from piml.models import FIGSRegressor
from piml.models import ReluDNNRegressor
#%%
# Data preparation and model instantiation
exp=Experiment()
exp.data_loader(data="BikeSharing")
exp.data_prepare(target='cnt', task_type='Regression')
train_x , train_y,_ = exp.get_data(train= True)
test_x , test_y,_= exp.get_data(test=True)
feature_names = exp.get_feature_names()
target_names = exp.get_target_name()
model_A = FIGSRegressor(max_iter=100)
model_B = ReluDNNRegressor(hidden_layer_sizes=(20, 30), batch_size=1000,
                           learning_rate=0.001)

exp.model_train(model=model_A, name="FIGS")
exp.model_train(model=model_B, name="ReluDNN")

#%%
# Model performance based on MSE.
exp.model_diagnose(model="ReluDNN", show='accuracy_table')
#%%
# Compare models' performance based on MSE.
exp.model_compare(models=["FIGS","ReluDNN"], show='accuracy_plot', metric="MSE", figsize=(5,4))
#%%
# Compare models' performance based on R-squared.
exp.model_compare(models=["FIGS","ReluDNN"], show='accuracy_plot',  metric="R2", figsize=(5,4))

