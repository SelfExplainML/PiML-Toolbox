
# -*- coding: utf-8 -*-
"""
Robustness:  Regression
=====================================

Evaluate model robustness
"""

#%%
# Imports
import numpy as np
from piml import Experiment
from piml.models import FIGSRegressor
from piml.models import ReluDNNRegressor
from piml.models import GLMRegressor
#%%
# Data preparation and model instantiation
exp=Experiment()
exp.data_loader(data="BikeSharing")
exp.data_prepare(target='cnt', task_type='Regression')
train_x , train_y,_ = exp.get_data(train= True)
test_x , test_y,_= exp.get_data(test=True)
feature_names = exp.get_feature_names()
target_names = exp.get_target_name()
model_A = FIGSRegressor(max_iter=100, max_depth=None, random_state=None)
model_B = ReluDNNRegressor(hidden_layer_sizes=(20, 30), batch_size=1000, learning_rate=0.001)
exp.model_train(model=model_A, name="FIGS")
exp.model_train(model=model_B, name="ReluDNN")
#%%
# Model performance.
exp.model_diagnose(model="ReluDNN", show='robustness',
                   perturb_features='All Features', alpha=0.3)
#%%
# Compare models' under worst case.
exp.model_compare(models=["FIGS","ReluDNN"], show='robustness_perf_worst',
                  alpha=0.3, figsize=(5,4))
#%%
# Comapre model Robustness : the perturbation step  size is 0.1
exp.model_compare(models=["FIGS","ReluDNN"], show='robustness_perf', figsize=(5,4))
#%%
# Comapre model Robustness : the perturbation step  size is 0.01
exp.model_compare(models=["FIGS","ReluDNN"], show='robustness_perf',
                  perturb_size=0.01, figsize=(5,4))
#%%             
# Train models under different regularizations.
model_list = []
regularization_grid = np.logspace(-5, -3, 3)
for reg in regularization_grid:
    name = "GLM_{}".format(reg)
    exp.model_train(model=GLMRegressor(l1_regularzation=reg),name=name)
    model_list.append(name)
#%%
# Compare models (worst case) under different regularizations.
exp.model_compare(models=model_list, show='robustness_perf_worst', 
                  figsize=(5,4))
#%%
#We may not only compare the Robustness performance under the worst-case scenario. For general robustness, set show to robustness_perf as follows.
exp.model_compare(models=model_list, show='robustness_perf',
                  alpha=0.3, figsize=(5,4))
