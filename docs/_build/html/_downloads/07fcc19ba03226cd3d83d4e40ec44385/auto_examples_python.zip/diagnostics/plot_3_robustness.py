
# -*- coding: utf-8 -*-
"""
Robustness: Classification
=====================================

Evaluate model robustness
"""

#%%
# Moodels instantiation and training
import ipywidgets
with ipywidgets.Output():
  from piml import Experiment
  from piml.models import FIGSClassifier
  from piml.models import ReluDNNClassifier
  from piml.models import GAMINetClassifier
  exp = Experiment()
  exp.data_loader(data='TaiwanCredit')
  exp.data_summary(feature_exclude=["LIMIT_BAL", "SEX", "EDUCATION", "MARRIAGE", "AGE"], feature_type={})
  exp.data_prepare(target='FlagDefault', task_type='Classification', test_ratio=0.2, random_state=0)
exp.model_train(FIGSClassifier(max_iter=200, max_depth=None, splitter='best', min_samples_leaf=1,
                               min_impurity_decrease=0, learning_rate=0.0002,
                               random_state=None),name="FIGS")
exp.model_train(ReluDNNClassifier(hidden_layer_sizes=(60,60), l1_reg=0.0002, batch_size=200,
                                  learning_rate=0.0002),name="ReluDNN_A")
exp.model_train(ReluDNNClassifier(hidden_layer_sizes=(60,60), l1_reg=0.003, batch_size=200,
                                  learning_rate=0.0002),name="ReluDNN_B")
exp.model_train(GAMINetClassifier(interact_num=10, loss_threshold=0.01,
                                  subnet_size_main_effect=[20],
                                  subnet_size_interaction=[20,20]),name='GAMINet')

#%%
# Model performance on natural data (No perturbation appied)
exp.model_compare(models=["FIGS","ReluDNN_A","ReluDNN_B","GAMINet"],
                  show='accuracy_auc', figsize=(5,4))
#%%
# PiML offers the flexibility to choose a perturbation step size. The plot below is under the default step size (0.1).
exp.model_diagnose(model="ReluDNN_A", show='robustness',
                   perturb_features='All Features', alpha=0.3)
#%%
# In the following plot, we consider the step size of 0.01.
exp.model_diagnose(model="ReluDNN_A", show='robustness',
                   perturb_size=0.01,
                   perturb_features='All Features', alpha=0.3)
#%%
# Comapre models 
exp.model_compare(models=["FIGS","ReluDNN_A", "ReluDNN_B", "GAMINet"],
                  show='robustness_perf_worst', alpha=0.3, figsize=(5,4))
#%%
# Comapre model Robustness 
exp.model_compare(models=["FIGS","ReluDNN_A","ReluDNN_B","GAMINet"],
                  show='robustness_perf', figsize=(5,4))
#%%
# Comapre models
exp.model_compare(models=["FIGS","ReluDNN_A","ReluDNN_B","GAMINet"],
                  perturb_method = 'quantile',
                  show='robustness_perf', figsize=(5,4))


