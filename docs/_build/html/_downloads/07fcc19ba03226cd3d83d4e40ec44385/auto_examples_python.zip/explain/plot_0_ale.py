# -*- coding: utf-8 -*-
"""
ALE:  Regression
=====================================

Global ALE on BikeSharing data 
"""

#%%
from piml import Experiment
from piml.models import GAMINetRegressor
exp = Experiment()
exp.data_loader(data='BikeSharing')
exp.data_summary(feature_exclude=["season", "workingday", "atemp"])
exp.data_prepare(target='cnt', task_type='Regression', test_ratio=0.2, random_state=0)
regressor_model = GAMINetRegressor()
exp.model_train(model=regressor_model, name='GAMINetRegressor')
#%%
# Plot ALE
exp.model_explain(model='GAMINetRegressor', show='ale', uni_feature='weathersit',
                  original_scale=True)
#%%
exp.model_explain(model='GAMINetRegressor', show='ale',
                  uni_feature='hr', original_scale=True)
#%%
exp.model_explain(model='GAMINetRegressor', show='ale',
                  original_scale=True, bi_features=['weekday', 'hr'])
