# -*- coding: utf-8 -*-
"""
PDP:  Regression
=====================================

Partial Dependence Plot (PDP) on  Regression problem 
"""

#%%
from piml import Experiment
from piml.models import ReluDNNRegressor
exp = Experiment()
exp.data_loader(data='BikeSharing')
exp.data_summary(feature_exclude=["season","workingday","atemp"])
exp.data_prepare(target='cnt', task_type='Regression', test_ratio=0.2, random_state=0)
regressor_model=ReluDNNRegressor(hidden_layer_sizes=(40, 40), l1_reg=1e-05,
                                        batch_size=500, learning_rate=0.001)
exp.model_train(model=regressor_model, name='ReLU_DNN')
#%%
# PDP Plots
exp.model_explain(model='ReLU_DNN', show='pdp', original_scale=True,
                  uni_feature='hr')
#%%
exp.model_explain(model='ReLU_DNN', show='pdp', original_scale=True,
                  uni_feature='holiday')
#%%
exp.model_explain(model='ReLU_DNN', show='pdp',original_scale=True, 
                  bi_features=['hr','weathersit'])
