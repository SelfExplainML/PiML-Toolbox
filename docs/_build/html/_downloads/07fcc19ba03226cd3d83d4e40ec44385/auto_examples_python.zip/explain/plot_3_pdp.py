# -*- coding: utf-8 -*-
"""
PDP:  Classification
=====================================

Partial Dependence Plot on Classification problem
"""

#%%
from piml import Experiment
from piml.models import ReluDNNClassifier
exp = Experiment()
exp.data_loader(data='TaiwanCredit')
exp.data_summary(feature_exclude=["LIMIT_BAL", "SEX", "EDUCATION", "MARRIAGE", "AGE"], feature_type={})
exp.data_prepare(target='FlagDefault', task_type='Classification', test_ratio=0.2, random_state=0)
classifier_model = ReluDNNClassifier(hidden_layer_sizes=(40, 40), 
                                     l1_reg=0.0008, batch_size=500, learning_rate=0.001)
exp.model_train(model=classifier_model, name='ReLU_DNN')
#%%
# PDP Plots
exp.model_explain(model='ReLU_DNN', show='pdp', uni_feature='PAY_1')
#%%
exp.model_explain(model='ReLU_DNN', show='pdp', original_scale=True, bi_features=['PAY_1', 'PAY_2'])
