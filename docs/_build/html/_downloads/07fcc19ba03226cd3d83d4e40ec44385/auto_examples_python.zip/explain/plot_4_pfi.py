# -*- coding: utf-8 -*-
"""
PFI:  Classification
=====================================

Permutation Feature Importance plot on a Classification problem
"""

#%%
from piml import Experiment
from piml.models import GAMINetClassifier
exp=Experiment()
exp.data_loader(data='TaiwanCredit')
exp.data_summary(feature_exclude=["LIMIT_BAL", "SEX", "EDUCATION", "MARRIAGE", "AGE"], feature_type={})
exp.data_prepare(target='FlagDefault', task_type='Classification', test_ratio=0.2, random_state=0)
classifier_model=GAMINetClassifier(interact_num=10, loss_threshold=0.01,
                                   subnet_size_main_effect=[20],
                                   subnet_size_interaction=[20,20])
exp.model_train(model=classifier_model, name='GAMI-Net')
#%%
# PFI Plot
exp.model_explain(model="GAMI-Net", show='pfi', original_scale=True, uni_feature='PAY_1')

