# -*- coding: utf-8 -*-
"""
Decision Tree: Classification Tree Model
=========================================
Decision Tree
"""
#%%
from piml import Experiment
from piml.models import PiDecisionTreeClassifier
exp = Experiment()
exp.data_loader(data="CoCircles")
exp.data_prepare(target='target', task_type='Classification', test_ratio=0.2)
exp.model_train(model=PiDecisionTreeClassifier(max_depth=6), name='Tree')

#%%
# Global interpretation starting from the root node.
exp.model_interpret(model='Tree', show="tree_global", root=0, depth=3, original_scale=True, figsize=(20, 6))
#%%
# Global interpretation starting from the 10-th node.
exp.model_interpret(model='Tree', show="tree_global", root=10, depth=3, figsize=(20, 10))
#%%
# Local interpretation.
exp.model_interpret(model='Tree', show="tree_local", sample_id=0, figsize=(20, 6))
