# -*- coding: utf-8 -*-
"""
Generalized Additive Model
=====================================

GAM Regression
"""

#%%
from piml import Experiment
from piml.models import ExplainableBoostingClassifier
exp = Experiment()
exp.data_loader(data='TaiwanCredit')
exp.data_summary(feature_exclude=["LIMIT_BAL", "SEX", "EDUCATION", "MARRIAGE", "AGE"], feature_type={})
exp.data_prepare(target='FlagDefault', task_type='Classification', test_ratio=0.2, random_state=0)

#%%
# Model Training
exp.model_train(model=ExplainableBoostingClassifier(), name='EBM')

#%%
# Global interpretation
exp.model_interpret(model='EBM', show="global_fi")

exp.model_interpret(model='EBM', show="global_ei")

exp.model_interpret(model='EBM', show="global_effect_plot", uni_feature="PAY_1")

#%%
# Local interpretation
exp.model_interpret(model='EBM', show="local_fi", sample_id=0)
exp.model_interpret(model='EBM', show="local_ei", sample_id=0)
