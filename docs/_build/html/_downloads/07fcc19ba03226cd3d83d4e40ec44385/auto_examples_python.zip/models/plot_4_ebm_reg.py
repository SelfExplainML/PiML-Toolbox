# -*- coding: utf-8 -*-
"""
Generalized Additive Model
=====================================

GAM Regression
"""

#%%
from piml import Experiment
from piml.models import ExplainableBoostingRegressor
exp = Experiment()
exp.data_loader(data="BikeSharing")
exp.data_summary(feature_exclude=["season", "workingday", "atemp"])
exp.data_prepare(target='cnt', task_type='Regression')


#%%
# Model Training
exp.model_train(model=ExplainableBoostingRegressor(), name='EBM')

#%%
# Global interpretation
exp.model_interpret(model='EBM', show="global_fi")

exp.model_interpret(model='EBM', show="global_ei")

exp.model_interpret(model='EBM', show="global_effect_plot", uni_feature="hr")

#%%
# Local interpretation
exp.model_interpret(model='EBM', show="local_fi", sample_id=0)
exp.model_interpret(model='EBM', show="local_ei", sample_id=0)
