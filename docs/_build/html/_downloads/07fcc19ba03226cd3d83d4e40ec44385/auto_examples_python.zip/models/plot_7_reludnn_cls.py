# -*- coding: utf-8 -*-
"""
ReLU DNN: Classification 
=====================================
Train a ReLU DNN model on the TaiwanCredit data, and interpret the fitted model.

"""

#%%
import matplotlib.pyplot as plt
from piml import Experiment
from piml.models import ReluDNNClassifier
exp = Experiment()
exp.data_loader(data='TaiwanCredit')
exp.data_summary(feature_exclude=["LIMIT_BAL", "SEX", "EDUCATION", "MARRIAGE", "AGE"], feature_type={})
exp.data_prepare(target='FlagDefault', task_type='Classification', test_ratio=0.2, random_state=0)

# Train the models.
# Register models.
exp.model_train(model=ReluDNNClassifier(hidden_layer_sizes=(40, 40), l1_reg=0.0002, learning_rate=0.001),
                name="ReLUDNN")

#Local Linear Model (LLM) summary plot.
exp.model_interpret(model="ReLUDNN", show='llm_summary', figsize=(6, 5))
#%%
#Local Linear Model (LLM) parallel coordinate plot.
exp.model_interpret(model="ReLUDNN", show='llm_pc', figsize=(6, 5))
#%%
#Local Linear Model (LLM) violin plot.
exp.model_interpret(model="ReLUDNN", show='llm_violin', figsize=(6, 5))
#%%
# Models global feature importance 
exp.model_interpret(model="ReLUDNN", show='global_fi', figsize=(6, 5))
#%%
# Model global effect plot. 
exp.model_interpret(model="ReLUDNN", show='global_effect_plot', uni_feature='PAY_1', figsize=(6, 5))
#%%
# Model global effect plot: In this case, we consider two features
exp.model_interpret(model="ReLUDNN", show='global_effect_plot', bi_features=['PAY_1', 'PAY_3'], figsize=(6, 5))

#%%
# Model local feature importance without centering.
exp.model_interpret(model="ReLUDNN", show='local_fi', sample_id=0, centered=False, figsize=(6, 5))
#%%
# Model local feature importance with centering. 
exp.model_interpret(model="ReLUDNN", show='local_fi', sample_id=0, centered=True, figsize=(6, 5))

#%%
# Function for ploting the training and validation losses
def train_val_plot(loss_train, loss_val):
    plt.figure(figsize=(6.5, 4))
    epochs = range(len(loss_train))
    plt.plot(epochs, loss_train, 'r', label='Training loss')
    plt.plot(epochs, loss_val, 'g', label='validation loss')
    plt.title('Training and Validation loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.show()

train_val_plot(exp.get_model("ReLUDNN").estimator.train_epoch_loss_,
               exp.get_model("ReLUDNN").estimator.valid_epoch_loss_)
