# -*- coding: utf-8 -*-
"""
ReLU DNN: Regression 
=====================================
Train a ReLU DNN model on the BikeSharing data, and interpret the fitted model.

"""

#%%
import numpy as np
from piml import Experiment
from piml.models import ReluDNNRegressor
exp = Experiment()
exp.data_loader(data="BikeSharing")
exp.data_summary(feature_exclude=["season", "workingday", "atemp"])
exp.data_prepare(target='cnt', task_type='Regression')

# Train the models.
# Register models.
exp.model_train(model=ReluDNNRegressor(hidden_layer_sizes=(40, 40), l1_reg=0.0002, learning_rate=0.001),
                name="ReLUDNN")

#Local Linear Model (LLM) summary plot.
exp.model_interpret(model="ReLUDNN", show='llm_summary', figsize=(6, 5))
#%%
#Local Linear Model (LLM) parallel coordinate plot.
exp.model_interpret(model="ReLUDNN", show='llm_pc', figsize=(6, 5))
#%%
#Local Linear Model (LLM) violin plot.
exp.model_interpret(model="ReLUDNN", show='llm_violin', figsize=(6, 5))
#%%
# Models global feature importance 
exp.model_interpret(model="ReLUDNN", show='global_fi', figsize=(6, 5))
#%%
# Model global effect plot. 
exp.model_interpret(model="ReLUDNN", show='global_effect_plot', uni_feature='hr', figsize=(6, 5))
#%%
# Model global effect plot: In this case, we consider two features
exp.model_interpret(model="ReLUDNN", show='global_effect_plot', bi_features=['hr', 'temp'], figsize=(6, 5))

#%%
# Model local feature importance without centering.
exp.model_interpret(model="ReLUDNN", show='local_fi', sample_id=0, centered=False, figsize=(6, 5))
#%%
# Model local feature importance with centering. 
exp.model_interpret(model="ReLUDNN", show='local_fi', sample_id=0, centered=True, figsize=(6, 5))
